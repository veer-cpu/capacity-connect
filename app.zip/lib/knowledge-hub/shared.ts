import { createClient } from "@/lib/supabase/server";

export const KNOWLEDGE_RESOURCE_TYPES = [
    "pdf",
    "presentation",
    "video",
    "external_link",
    "guide",
    "sop",
    "case_study",
    "operational_note",
    "best_practice",
    "document",
] as const;

export type KnowledgeResourceType = (typeof KNOWLEDGE_RESOURCE_TYPES)[number];

export const KNOWLEDGE_RESOURCE_STATUSES = [
    "pending",
    "approved",
    "rejected",
    "archived",
] as const;

export type KnowledgeResourceStatus = (typeof KNOWLEDGE_RESOURCE_STATUSES)[number];

export const KNOWLEDGE_RESOURCE_TYPE_LABELS: Record<KnowledgeResourceType, string> = {
    pdf: "PDF",
    presentation: "Presentation",
    video: "Video",
    external_link: "External Link",
    guide: "Guide",
    sop: "SOP",
    case_study: "Case Study",
    operational_note: "Operational Note",
    best_practice: "Best Practice",
    document: "Document",
};

export const KNOWLEDGE_HUB_BUCKET = "knowledge-hub";

export function isKnowledgeResourceType(
    value: string | null | undefined
): value is KnowledgeResourceType {
    return (
        !!value &&
        (KNOWLEDGE_RESOURCE_TYPES as readonly string[]).includes(value)
    );
}

/** Strips characters that could break a PostgREST `.or()` filter expression. */
export function sanitizeSearchTerm(input: string): string {
    return input.replace(/[%,()]/g, "").trim().slice(0, 100);
}

export type CompetencyOption = { id: string; name: string };

export async function getActiveCompetencyOptions(): Promise<CompetencyOption[]> {
    const supabase = await createClient();

    const { data, error } = await supabase
        .from("competencies")
        .select("id, name")
        .eq("is_active", true)
        .order("name");

    if (error) {
        console.error("Unable to load competencies for knowledge hub filters:", error);
        return [];
    }

    return data ?? [];
}

export type CourseOption = { id: string; title: string };

export async function getTrainerCourseOptions(
    trainerId: string
): Promise<CourseOption[]> {
    const supabase = await createClient();

    const { data, error } = await supabase
        .from("courses")
        .select("id, title")
        .eq("trainer_id", trainerId)
        .order("title");

    if (error) {
        console.error("Unable to load trainer courses for knowledge hub:", error);
        return [];
    }

    return data ?? [];
}

type SupabaseServerClient = Awaited<ReturnType<typeof createClient>>;

type RelatableRow = {
    uploaded_by: string | null;
    competency_id: string | null;
    course_id: string | null;
};

export type RelatedNameMaps = {
    profileMap: Map<string, string>;
    competencyMap: Map<string, string>;
    courseMap: Map<string, { title: string; slug: string }>;
};

/** Batch-resolves uploader, competency and course display names for a set of knowledge resource rows. */
export async function buildRelatedNameMaps(
    supabase: SupabaseServerClient,
    rows: RelatableRow[]
): Promise<RelatedNameMaps> {
    const uploaderIds = [
        ...new Set(rows.map((row) => row.uploaded_by).filter((v): v is string => !!v)),
    ];
    const competencyIds = [
        ...new Set(rows.map((row) => row.competency_id).filter((v): v is string => !!v)),
    ];
    const courseIds = [
        ...new Set(rows.map((row) => row.course_id).filter((v): v is string => !!v)),
    ];

    const [profilesResult, competenciesResult, coursesResult] = await Promise.all([
        uploaderIds.length
            ? supabase.from("profiles").select("id, full_name").in("id", uploaderIds)
            : Promise.resolve({ data: [] as { id: string; full_name: string }[] }),
        competencyIds.length
            ? supabase.from("competencies").select("id, name").in("id", competencyIds)
            : Promise.resolve({ data: [] as { id: string; name: string }[] }),
        courseIds.length
            ? supabase.from("courses").select("id, title, slug").in("id", courseIds)
            : Promise.resolve({ data: [] as { id: string; title: string; slug: string }[] }),
    ]);

    return {
        profileMap: new Map(
            (profilesResult.data ?? []).map((row) => [row.id, row.full_name])
        ),
        competencyMap: new Map(
            (competenciesResult.data ?? []).map((row) => [row.id, row.name])
        ),
        courseMap: new Map(
            (coursesResult.data ?? []).map((row) => [
                row.id,
                { title: row.title, slug: row.slug },
            ])
        ),
    };
}
