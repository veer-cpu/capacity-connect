export const KNOWLEDGE_RESOURCE_TYPES = [
  "pdf",
  "presentation",
  "video",
  "external_link",
  "guide",
  "sop",
  "case_study",
  "operational_note",
  "best_practice",
  "document",
] as const

export const KNOWLEDGE_RESOURCE_STATUSES = [
  "pending",
  "approved",
  "rejected",
  "archived",
] as const

export type KnowledgeResourceType =
  (typeof KNOWLEDGE_RESOURCE_TYPES)[number]

export type KnowledgeResourceStatus =
  (typeof KNOWLEDGE_RESOURCE_STATUSES)[number]